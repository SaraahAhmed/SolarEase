import 'package:flutter/material.dart';

class PanelModel
{
  final String? Panelimage;
  final String? PanelBrandName;
  final String ? PanelPrice;
  final String? PanelCapacity;
  final String ? totalPrice;

  PanelModel({
    required this.Panelimage,
    required this.PanelBrandName,
    required this.PanelCapacity,
    required this.PanelPrice,
    required this.totalPrice,
  });
  factory PanelModel.fromJson(json)
  {
    return PanelModel(
      Panelimage: json['imageUrl'], 
      PanelBrandName: json['brand'],
       PanelCapacity: json['capacity_Unit'], 
       PanelPrice: json['priceStr'], 
       totalPrice: json['totalPriceStr'], 

    );
  }


}
// -------------------------------------------------------------------



class BatteryModel
{
  final String Batteryimage;
  final String BatteryBrandName;
  final String BatteryPrice;
  final String BatteryCapacity;

  BatteryModel({ required this.Batteryimage,required this.BatteryBrandName,required this.BatteryCapacity,required this.BatteryPrice});
  factory BatteryModel.fromJson(json)
  {
    return BatteryModel(
      Batteryimage:json['imageUrl'], 
      BatteryBrandName: json['brand'], 
      BatteryCapacity: json['capacity_Unit'], 
      BatteryPrice: json['priceStr'],
      );
  }

}

//--------------------------------------------------------------------

class InverterModel
{
  final String Inverterimage;
  final String InverterBrandName;
  final String InverterPrice;
  final String InverterCapacity;

  InverterModel({ required this.Inverterimage,required this.InverterBrandName,required this.InverterCapacity,required this.InverterPrice, });
  factory InverterModel.fromJson(json)
  {
    return InverterModel(
      Inverterimage: json['imageUrl'], 
      InverterBrandName: json['brand'],  
      InverterCapacity: json['capacity_Unit'],
      InverterPrice:json['priceStr'], 
    );
  }
}