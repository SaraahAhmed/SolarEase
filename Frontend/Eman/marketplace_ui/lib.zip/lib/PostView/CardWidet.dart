import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:marketplace_ui/APIService/SmallPostModel.dart';
import 'package:marketplace_ui/PostView/UsersPosts.dart';
import 'package:marketplace_ui/PostView/whenclick.dart';
import 'package:marketplace_ui/main.dart';



class CardWidet extends StatefulWidget {
    Smallpostmodel smallpostmodel;
    CardWidet({required this.smallpostmodel,});


  @override
  _CardWidetState createState() => _CardWidetState();
}

class _CardWidetState extends State<CardWidet> {
  bool isFavorite = false;

  @override
  Widget build(BuildContext context) { //color: Color(0xffcdefbd),
    return SizedBox(
       height: height(196),
       width: width(370),
      child: InkWell(
         onTap: () {
        // Define the action to take when the card is tapped
        //return ClickedPOst();
         Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ClickedPOst(title: '',)),
        );
        print('Card tapped!');
      },
        child: Card
        (
          color: Color(0xffD9EDCA),
          //color: Color(0xffD9EDCA), //#D9EDCA
          child: Column
          (
           
            children: 
            [
               
              Padding(
                padding: const EdgeInsets.only(left: 8,top: 14),
                child: _UserProfileBuilder(smallpostmodel: widget.smallpostmodel),
              ),
        
              Align(
                  alignment: Alignment.center,
                child: Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: _buildImage(smallpostmodel: widget.smallpostmodel),
                )),
              Padding(
                padding: const EdgeInsets.only(left: 16,top: 12),
                child: Row(children: [
                 _TextBuilder(smallpostmodel:widget.smallpostmodel),
                 
                ],),
              ),
            Align(
                 alignment: Alignment.topRight,
                child: IconButton(
                  onPressed: (){setState(() {isFavorite = !isFavorite;});},
                  icon: Icon
                  (
                    isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: isFavorite ? Colors.orange : Colors.black,
                  ),
                ),
              ),
            
            ],
          ),
          
        ),
      ),
    );
  }

}
// -----------------------------------------------------
Widget _TextBuilder({required smallpostmodel}) 
{
  return Expanded(
    child:  SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(smallpostmodel.ProductName,style: TextStyle(fontSize:14,fontWeight: FontWeight.bold),),
      
          Row(
            children: [
              Icon(Icons.monetization_on,size: 16,),
              Text(smallpostmodel.ProductPrice, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            ],
          ),
          Row(
            children: [
              Icon(Icons.location_on,size: 16,),
              Text(smallpostmodel.City, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              
            ],
          ),
        ],
      ),
    ),
  );
}
// ------------------------------------------------------

SizedBox _buildImage({required smallpostmodel}) {
  return SizedBox(
    width: width(300),
    height: height(60),
    child: ClipRRect(
     borderRadius: BorderRadius.all(Radius.circular(35)), 
     child: Image.network("http://solareasegp.runasp.net/"+smallpostmodel.ProductImage),
      //child: Image.asset(smallpostmodel.ProductImage, fit: BoxFit.fill,),
    ),
  );
}

// ----------------------------------------------------
Widget _UserProfileBuilder({required smallpostmodel}) {
  return Row(
    children: [
      CircleAvatar(
        radius: 25,
        backgroundImage: NetworkImage("http://solareasegp.runasp.net/"+smallpostmodel.UserProfileImage ?? 'assets/N.png'),
        //backgroundImage: AssetImage(smallpostmodel.UserProfileImage?? 'assets/N.png'),
      ),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 8),
            child: Text(smallpostmodel.UserName,style: TextStyle(fontSize: 14,fontWeight: FontWeight.bold),),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 8),
            child: Text(smallpostmodel.date,style: TextStyle(color: Colors.grey),),
          )
        ],
      )
    ],
  );
}
// ----------------------------------------------
// Align(
//                alignment: Alignment.centerLeft,
//               child: IconButton(
//                 onPressed: (){setState(() {isFavorite = !isFavorite;});},
//                 icon: Icon
//                 (
//                   isFavorite ? Icons.favorite : Icons.favorite_border,
//                   color: isFavorite ? Colors.orange : Colors.black,
//                 ),
//               ),
//             ),
//             _UserProfileBUilder(),