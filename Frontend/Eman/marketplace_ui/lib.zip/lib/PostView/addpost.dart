import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:image_picker/image_picker.dart';

double scw = 0; // 60% of screen width
double sch = 0;
double t = 0;

class MyCustomScrollBehavior extends MaterialScrollBehavior {
  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
      };
}

double wid(double w) {
  return scw * (w / 420);
}

double hig(double h) {
  return (h / 592) * sch;
}

//void main() => runApp(addpost());

class addpost extends StatefulWidget {
  @override
  _addpostState createState() => _addpostState();
}

class _addpostState extends State<addpost> {
  String dropdownValue = 'Electricity Bills';

  @override
  Widget build(BuildContext context) {
    scw = MediaQuery.of(context).size.width; // 60% of screen width
    sch = MediaQuery.of(context).size.height;
    t = MediaQuery.of(context).textScaleFactor;
    return MaterialApp(
      scrollBehavior: MyCustomScrollBehavior(),
      home: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: hig(100), //=100
                  width: double.infinity,
                  child: Stack(
                    children: [
                      Positioned(
                        top: 0,
                        right: 0,
                        child: Image.asset(
                          'assets/addpost/cloud.png',
                          fit: BoxFit.fill,
                          width: wid(140), //=140
                          height: hig(90), //=90
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: () {
                              Navigator.pop(context);
                              print('Arrow tapped');
                            },
                            child: Image.asset(
                              'assets/addpost/arrow.png',
                              width: wid(78),
                              height: hig(70),
                            ),
                          ),
                          Text(
                            'Add Post',
                            style: TextStyle(
                              fontSize: 25.0 * t,
                              fontWeight: FontWeight.bold,
                              color: Color(0x0ff063221),
                            ),
                          ),
                          SizedBox(
                            width: wid(78),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                MonthContainer(),
                SizedBox(height: hig(5))
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MonthContainer extends StatefulWidget {
  @override
  _MonthContainerState createState() => _MonthContainerState();
}

class _MonthContainerState extends State<MonthContainer> {
  Uint8List? _image;
  TextEditingController controller = TextEditingController();
  String? selectedCategory;
  String? selectedBrand;

  final Map<String, List<String>> brandsForCategory = {
    'Panels': ["brand1", "brand2", "brand3", "brand5", "brand6"],
    'Inverter': ["brand7", "brand8", "brand9"],
    'Battery': ["brand10", "brand11", "brand12"],
    'Other': ["brand13", "brand14", "brand15"],
  };

  @override
  Widget build(BuildContext context) {
    return Container(
      width: wid(378),
      height: hig(490),
      decoration: BoxDecoration(
        color: Color(0xffE1F1D5),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Center(
        child: SizedBox(
          width: wid(357),
          height: hig(475),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: hig(9),
              ),
              GestureDetector(
                onTap: pickImage,
                child: Center(
                  child: Image(
                    image: _image == null
                        ? AssetImage('assets/addpost/add.png')
                        : MemoryImage(_image!) as ImageProvider,
                    fit: BoxFit.fill,
                    width: wid(222),
                    height: hig(120), //=140
                  ),
                ),
              ),
              SizedBox(
                height: hig(9),
              ),
              conmponentlist(wid(357), hig(30), "is used", wid(82), wid(95),
                  ["yes", "no"]),
              conmponentlist(wid(357), hig(30), "Category", wid(156), wid(95), [
                "Panels",
                "Inverter",
                "Battery",
                "Other"
              ], onChanged: (value) {
                setState(() {
                  selectedCategory = value;
                  selectedBrand =
                      null; // Reset selected brand when category changes
                });
              }),
              if (selectedCategory == 'Battery')
                Row(
                  children: [
                    conmponent(
                      wid(357),
                      hig(30),
                      "Volume",
                      wid(67),
                      wid(95),
                    ),
                  ],
                ),
              Row(
                children: [
                  conmponent(wid(190), hig(30), "Capacity", wid(90), wid(95)),
                  SizedBox(
                    width: wid(1),
                  ),
                  conmponentlist(wid(135), hig(30), "Unit", wid(100), wid(35),
                      ["Waat", "KWh", "Ambeer"]),
                ],
              ),
              conmponent(
                wid(357),
                hig(30),
                "Brand",
                wid(156),
                wid(95),
              ),
              conmponent(wid(357), hig(30), "Price", wid(90), wid(95)),
              conmponent(wid(357), hig(30), "Phone", wid(156), wid(95)),
              conmponentlist(wid(357), hig(30), "City", wid(156), wid(95),
                  ["Cairo", "Alex", "Aswan", "Giza"]),
              Text(
                "Description",
                style: TextStyle(
                  fontSize: 15.0 * t,
                  fontWeight: FontWeight.bold,
                  color: Color(0x0ff063221),
                ),
              ), //320
              conmponent(wid(357), hig(40), "Description", wid(357), 0),
              SizedBox(height: hig(11)),
              Expanded(
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: SizedBox(
                    height: hig(30),
                    width: wid(168),
                    child: ElevatedButton(
                      onPressed: () {
                        // Add functionality here
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            Color(0xffED9555), // Set background color
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                              25), // Set circular border radius
                        ),
                      ),
                      child: Text(
                        'Share',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          // Set text color
                          fontSize: 16 * t,
                        ),
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  void pickImage() async {
    ImagePicker imagePicker = ImagePicker();
    try {
      var pickedFile = await imagePicker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        var imageBytes = await pickedFile.readAsBytes();
        setState(() {
          _image = imageBytes;
        });
      }
    } catch (e) {
      print("Error picking image: $e");
    }
  }
}

class conmponentlist extends StatefulWidget {
  TextEditingController controller = TextEditingController();
  double w;
  double h;
  double w_;
  double wt;
  String txt;
  List<String> dropdownItems;
  final void Function(String?)? onChanged;

  conmponentlist(this.w, this.h, this.txt, this.w_, this.wt, this.dropdownItems,
      {this.onChanged});

  @override
  _conmponentlistState createState() => _conmponentlistState();
}

class _conmponentlistState extends State<conmponentlist> {
  String? dropdownValue;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.w,
      height: widget.h,
      child: Row(
        children: [
          SizedBox(
            width: widget.wt,
            child: Text(
              widget.txt,
              style: TextStyle(
                fontSize: 15.0 * t,
                fontWeight: FontWeight.bold,
                color: Color(0x0ff063221),
              ),
            ),
          ),
          Container(
            width: widget.w_,
            height: hig(17), //20
            decoration: BoxDecoration(
              color: Color(0xffD9D9D9),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: wid(4.2)),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  borderRadius: BorderRadius.circular(20),
                  isDense: true,
                  value: dropdownValue,
                  onChanged: (String? newValue) {
                    setState(() {
                      dropdownValue = newValue;
                    });
                    if (widget.onChanged != null) {
                      widget.onChanged!(newValue);
                    }
                  },
                  items: widget.dropdownItems
                      .map<DropdownMenuItem<String>>(
                        (String value) => DropdownMenuItem<String>(
                          value: value,
                          child: Text(value,
                              style: TextStyle(
                                fontSize: 13 * t,
                                fontWeight: FontWeight.bold,
                              )),
                        ),
                      )
                      .toList(),
                  dropdownColor: Color(0xffD9D9D9),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}

class conmponent extends StatelessWidget {
  TextEditingController controller = TextEditingController();
  double w;
  double h;
  double w_;
  double wt;
  String txt;
  conmponent(this.w, this.h, this.txt, this.w_, this.wt);
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: w, //150
      height: h, //40
      child: Row(
        children: [
          SizedBox(
            width: wt,
            child: Text(
              txt,
              style: TextStyle(
                fontSize: 15.0 * t,
                fontWeight: FontWeight.bold,
                color: Color(0x0ff063221),
              ),
            ),
          ),
          if (txt != "Description")
            (Container(
                width: w_, // Set the width
                height: hig(17), // Set the height
                decoration: BoxDecoration(
                  color: Color(0xffD9D9D9), // Set the color
                  borderRadius: BorderRadius.circular(20),
                  // Set circular border radius
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: w * 0.0106),
                  child: TextField(
                    style: TextStyle(
                      fontSize: 13 * t,
                      fontWeight: FontWeight.bold,
                    ),
                    decoration: InputDecoration(
                      isDense: true,
                      border: InputBorder.none, // Remove default border
                    ),
                    controller: controller,
                  ),
                )))
          else
            (Container(
                height: h,
                width: w_, // Set the width
                // Set the height
                decoration: BoxDecoration(
                  color: Color(0xffD9D9D9), // Set the color
                  borderRadius:
                      BorderRadius.circular(15), // Set circular border radius
                ),
                child: TextField(
                  decoration: InputDecoration(
                    border: InputBorder.none, // Remove default border
                  ),
                  controller: controller,
                ))),
        ],
      ),
    );
  }
}
/*import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:image_picker/image_picker.dart';

class MyCustomScrollBehavior extends MaterialScrollBehavior {
  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
      };
}

// void main() => runApp(AddPost());

// class AddPost extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       scrollBehavior: MyCustomScrollBehavior(),
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: MyHomePage(title: 'Flutter Demo Home Page'),
//     );
//   }
// }

class AddPost extends StatefulWidget {


  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<AddPost> {
  String dropdownValue = 'Electricity Bills';

  @override
  Widget build(BuildContext context) {
    var w = MediaQuery.of(context).size.width; // 60% of screen width
    var h = MediaQuery.of(context).size.height;
    var t = MediaQuery.of(context).textScaleFactor;
    return MaterialApp(
      home: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: h * 0.15, //=100
                  width: double.infinity,
                  child: Stack(
                    children: [
                      Positioned(
                        top: 0,
                        right: 0,
                        child: Image.asset(
                          'assets/addpost/cloud.png',
                          fit: BoxFit.fill,
                          width: 0.37 * w, //=140
                          height: h * 0.135, //=90
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: () {
                              print('Arrow tapped');
                            },
                            child: Image.asset(
                              'assets/addpost/arrow.png',
                              width: 0.185 * w,
                              height: 0.12 * h,
                            ),
                          ),
                          Text(
                            'Add Post',
                            style: TextStyle(
                              fontSize: 25.0 * t,
                              fontWeight: FontWeight.bold,
                              color: Color(0x0ff063221),
                            ),
                          ),
                          SizedBox(
                            width: 0.185 * w,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                MonthContainer(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MonthContainer extends StatefulWidget {
  @override
  _MonthContainerState createState() => _MonthContainerState();
}

class _MonthContainerState extends State<MonthContainer> {
  Uint8List? _image;
  TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    var w = MediaQuery.of(context).size.width; // 60% of screen width
    var h = MediaQuery.of(context).size.height;
    var t = MediaQuery.of(context).textScaleFactor;
    return Container(
      width: w * 0.9,
      height: h * 0.8,
      decoration: BoxDecoration(
        color: Color(0xffE1F1D5),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Center(
        child: SizedBox(
          width: w * 0.85,
          height: h * 0.75,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: h * 0.015,
              ),
              GestureDetector(
                onTap: pickImage,
                child: Center(
                  child: Image(
                    image: _image == null
                        ? AssetImage('assets/addpost/add.png')
                        : MemoryImage(_image!) as ImageProvider,
                    fit: BoxFit.fill,
                    width: w * 0.53,
                    height: 0.20 * h, //=140
                  ),
                ),
              ),
              SizedBox(
                height: h * 0.015,
              ),
              conmponentlist(w * 0.85, h * 0.05, "is used", w * 0.186,
                  w * 0.226, ["yes", "no"]),
              conmponentlist(w * 0.85, h * 0.05, "Brand", w * 0.372, w * 0.226,
                  ["brand1", "brand2", "brand3", "brand5", "brand6"]),
              conmponentlist(w * 0.85, h * 0.05, "category", w * 0.372,
                  w * 0.226, ["Panels", "inverter", "Bettary", "other"]),
              conmponent(w * 0.85, h * 0.05, "Capacity", w * 0.16, w * 0.226),
              conmponent(w * 0.85, 35, "Price", w * 0.2125, w * 0.226),
              conmponent(w * 0.85, h * 0.05, "Phone", w * 0.372, w * 0.226),
              conmponentlist(w * 0.8, h * 0.05, "City", w * 0.372, w * 0.226,
                  ["Cairo", "Alex", "Aswan", "Giza"]),
              Text(
                "Description",
                style: TextStyle(
                  fontSize: 15.0 * t,
                  fontWeight: FontWeight.bold,
                  color: Color(0x0ff063221),
                ),
              ), //320
              conmponent(w * 0.85, h * 0.065, "Description", w * 0.85, 0),
              SizedBox(height: h * 0.015),
              Center(
                child: SizedBox(
                  height: h * 0.043,
                  width: w * 0.4,
                  child: ElevatedButton(
                    onPressed: () {
                      // Add functionality here
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          Color(0xffED9555), // Set background color
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                            25), // Set circular border radius
                      ),
                    ),
                    child: Text(
                      'Share',
                      style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold,
                        // Set text color
                        fontSize: 16 * t,
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  void pickImage() async {
    ImagePicker imagePicker = ImagePicker();
    try {
      var pickedFile = await imagePicker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        var imageBytes = await pickedFile.readAsBytes();
        setState(() {
          _image = imageBytes;
        });
      }
    } catch (e) {
      print("Error picking image: $e");
    }
  }
}

class conmponentlist extends StatefulWidget {
  TextEditingController controller = TextEditingController();
  double w;
  double h;
  double w_;
  double wt;
  String txt;
  List<String> dropdownItems;

  conmponentlist(
      this.w, this.h, this.txt, this.w_, this.wt, this.dropdownItems);

  @override
  _conmponentlistState createState() => _conmponentlistState();
}

class _conmponentlistState extends State<conmponentlist> {
  String? dropdownValue;

  @override
  Widget build(BuildContext context) {
    var w = MediaQuery.of(context).size.width; // 60% of screen width
    var h = MediaQuery.of(context).size.height;
    var t = MediaQuery.of(context).textScaleFactor;
    return SizedBox(
      width: widget.w,
      height: widget.h,
      child: Row(
        children: [
          SizedBox(
            width: widget.wt,
            child: Text(
              widget.txt,
              style: TextStyle(
                fontSize: 15.0 * t,
                fontWeight: FontWeight.bold,
                color: Color(0x0ff063221),
              ),
            ),
          ),
          Container(
            width: widget.w_,
            height: h * 0.0285, //20
            decoration: BoxDecoration(
              color: Color(0xffD9D9D9),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: w * 0.0106),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  borderRadius: BorderRadius.circular(20),
                  isDense: true,
                  value: dropdownValue,
                  onChanged: (String? newValue) {
                    setState(() {
                      dropdownValue = newValue;
                    });
                  },
                  items: widget.dropdownItems
                      .map<DropdownMenuItem<String>>(
                        (String value) => DropdownMenuItem<String>(
                          value: value,
                          child: Text(value,
                              style: TextStyle(
                                fontSize: 13 * t,
                                fontWeight: FontWeight.bold,
                              )),
                        ),
                      )
                      .toList(),
                  dropdownColor: Color(0xffD9D9D9),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}

class conmponent extends StatelessWidget {
  TextEditingController controller = TextEditingController();
  double w;
  double h;
  double w_;
  double wt;
  String txt;
  conmponent(this.w, this.h, this.txt, this.w_, this.wt);
  @override
  Widget build(BuildContext context) {
    var sw = MediaQuery.of(context).size.width; // 60% of screen width
    var sh = MediaQuery.of(context).size.height;
    var t = MediaQuery.of(context).textScaleFactor;
    return SizedBox(
      width: w, //150
      height: h, //40
      child: Row(
        children: [
          SizedBox(
            width: wt,
            child: Text(
              txt,
              style: TextStyle(
                fontSize: 15.0 * t,
                fontWeight: FontWeight.bold,
                color: Color(0x0ff063221),
              ),
            ),
          ),
          if (txt != "Description")
            (Container(
                width: w_, // Set the width
                height: sh * 0.0285, // Set the height
                decoration: BoxDecoration(
                  color: Color(0xffD9D9D9), // Set the color
                  borderRadius: BorderRadius.circular(20),
                  // Set circular border radius
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: w * 0.0106),
                  child: TextField(
                    style: TextStyle(
                      fontSize: 13 * t,
                      fontWeight: FontWeight.bold,
                    ),
                    decoration: InputDecoration(
                      isDense: true,
                      border: InputBorder.none, // Remove default border
                    ),
                    controller: controller,
                  ),
                )))
          else
            (Container(
                height: h,
                width: w_, // Set the width
                // Set the height
                decoration: BoxDecoration(
                  color: Color(0xffD9D9D9), // Set the color
                  borderRadius:
                      BorderRadius.circular(15), // Set circular border radius
                ),
                child: TextField(
                  decoration: InputDecoration(
                    border: InputBorder.none, // Remove default border
                  ),
                  controller: controller,
                ))),
        ],
      ),
    );
  }
}
*/