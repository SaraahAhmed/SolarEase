import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:marketplace_ui/PostView/mainPosttBody.dart';

double scw = 0; // 60% of screen width
double sch = 0;
double t = 0;

double wid(double w) {return scw * (w / 360);}
double hig(double h) {return (h / 592) * sch;}
class MyCustomScrollBehavior extends MaterialScrollBehavior 
{
  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
      };
}


class ClickedPOst extends StatefulWidget 
{
  ClickedPOst({required this.title});

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<ClickedPOst> 
{
  String dropdownValue = 'Electricity Bills';

  @override
  Widget build(BuildContext context) {
    scw = MediaQuery.of(context).size.width; // 60% of screen width
    sch = MediaQuery.of(context).size.height;
    t = MediaQuery.of(context).textScaleFactor;
    return MaterialApp(
      scrollBehavior: MyCustomScrollBehavior(),
      home: Scaffold(
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: hig(100), width: double.infinity,
                  child: Stack(
                    children: [
                      Positioned
                      (
                        top: 0, right: 0,
                        child: Image.asset(
                          'assets/whenclick/cloud.png',
                          fit: BoxFit.fill,width: wid(90),height: hig(90),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: (){Navigator.pop(context);},
                            child: Image.asset(
                              'assets/whenclick/arrow.png',
                              width: wid(70),height: hig(80)
                            ,),
                          ),
                          Text('MarketPlace',style: TextStyle(fontSize: 25.0 * t,fontWeight: FontWeight.bold,color: Color(0x0ff063221),),),
                          SizedBox(width: wid(70),),
                        ],
                      ),
                    ],
                  ),
                ),
                MainPostBody(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


// ------------------------------------------------------------------ 
