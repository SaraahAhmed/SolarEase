
// import 'package:dio/dio.dart';
// import 'package:flutter/material.dart';

// import 'package:marketplace_ui/APIService/ProductModel.dart';
// import 'package:marketplace_ui/APIService/ProductService.dart';
// import 'package:marketplace_ui/main.dart';

// class BatteryCard extends StatefulWidget {
//   @override
//   State<BatteryCard> createState() => _BatteryCardState();
// }

// class _BatteryCardState extends State<BatteryCard> {
//   bool isFavorite = false;
//   Future<BatteryModel> batteryModel = BatteryService(Dio()).getBatteryInfo();

//   @override
//   Widget build(BuildContext context) {
//     return SizedBox(
//       width: width(370),
//       height: height(130),
//       child: Card(
//         color: Color(0xffD9EDCA), // #D9EDCA
//         child: Column(
//           children: [
//             Align(
//               alignment: Alignment.centerLeft,
//               child: IconButton(
//                 onPressed: () {
//                   setState(() {
//                     isFavorite = !isFavorite;
//                   });
//                 },
//                 icon: Icon(
//                   isFavorite ? Icons.favorite : Icons.favorite_border,
//                   color: isFavorite ? Colors.orange : Colors.black,
//                 ),
//               ),
//             ),
//             FutureBuilder<BatteryModel>(
//               future: batteryModel,
//               builder: (context, snapshot) {
//                 if (snapshot.connectionState == ConnectionState.waiting) {
//                   return CircularProgressIndicator();
//                 } else if (snapshot.hasError) {
//                   return Text('Error: ${snapshot.error}');
//                 } else if (snapshot.hasData) {
//                   return Column(
//                     children: [
//                       Align(
//                         alignment: Alignment.center,
//                         child: _buildImageforBattery(batteryModel: snapshot.data!),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 16),
//                         child: _TextBuilderForBattery(batteryModel: snapshot.data!),
//                       ),
//                     ],
//                   );
//                 } else {
//                   return Text('No data');
//                 }
//               },
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// // ---------------------Main Panel Card -------------------------------
// class MainBatteryCard extends StatelessWidget {
//   const MainBatteryCard();

//   @override
//   Widget build(BuildContext context) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         BatteryCard(),
//         BatteryCard(),
//       ],
//     );
//   }
// }

// // --------------- ListView for Panel Card ---------------------------
// class BatteryCardList extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return ListView.builder(
//       itemCount: 20,
//       itemBuilder: (context, index) {
//         return MainBatteryCard();
//       },
//     );
//   }
// }

// // ---------------------------------------------------------------
// Widget _TextBuilderForBattery({required BatteryModel batteryModel}) {
//   return Expanded(
//     child: SingleChildScrollView(
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Icon(
//                 Icons.location_on,
//                 size: 16,
//               ),
//               Text(
//                 batteryModel.BatteryBrandName,
//                 style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
//               ),
//             ],
//           ),
//           Row(
//             children: [
//               Icon(
//                 Icons.location_on,
//                 size: 16,
//               ),
//               Text(
//                 batteryModel.BatteryPrice,
//                 style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
//               ),
//             ],
//           ),
//           Row(
//             children: [
//               Icon(
//                 Icons.calendar_today,
//                 size: 16,
//               ),
//               Text(
//                 batteryModel.BatteryCapacity,
//                 style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
//               ),
//             ],
//           ),
//         ],
//       ),
//     ),
//   );
// }

// Widget _buildImageforBattery({required BatteryModel batteryModel}) {
//   return SizedBox(
//     width: width(250),
//     height: height(50),
//     child: Image.network("http://solareasegp.runasp.net/" + batteryModel.Batteryimage),
//   );
// }



import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:marketplace_ui/APIService/ProductModel.dart';
import 'package:marketplace_ui/APIService/ProductService.dart';
import 'package:marketplace_ui/main.dart';

class BatteryCard extends StatefulWidget {
  final BatteryModel batteryModel;

  BatteryCard({required this.batteryModel});

  @override
  State<BatteryCard> createState() => _BatteryCardState();
}

class _BatteryCardState extends State<BatteryCard> {
  bool isFavorite = false;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width(370),
      height: height(130),
      child: Card(
        color: Color(0xffD9EDCA), // #D9EDCA
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: IconButton(
                onPressed: () {
                  setState(() {
                    isFavorite = !isFavorite;
                  });
                },
                icon: Icon(
                  isFavorite ? Icons.favorite : Icons.favorite_border,
                  color: isFavorite ? Colors.orange : Colors.black,
                ),
              ),
            ),
            Column(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: _buildImageforBattery(batteryModel: widget.batteryModel),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: _TextBuilderForBattery(batteryModel: widget.batteryModel),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// --------------- ListView for Battery Card ---------------------------
class BatteryCardList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<BatteryModel>>(
      future: BatteryService(Dio()).getBatteryInfo(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(child: Text('No data available'));
        } else {
          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              return Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: BatteryCard(batteryModel: snapshot.data![index]),
                  ),
                  BatteryCard(batteryModel: snapshot.data![index]),
                ],
              );
            },
          );
        }
      },
    );
  }
}

// ---------------------------------------------------------------
Widget _TextBuilderForBattery({required BatteryModel batteryModel}) {
  return Expanded(
    child: SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            batteryModel.BatteryBrandName,
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),
          Row(
            children: [
              Icon(Icons.monetization_on, size: 16),
              Text(
                batteryModel.BatteryPrice,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
            ],
          ),
          // Row(
          //   children: [
          //     Icon(Icons.location_on, size: 16),
          //     Text(
          //       batteryModel.BatteryPrice ?? 'N/A',
          //       style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
          //     ),
          //   ],
          // ),
          Row(
            children: [
              Icon(Icons.calendar_today, size: 16),
              Text(
                batteryModel.BatteryCapacity,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

SizedBox _buildImageforBattery({required BatteryModel batteryModel}) {
  return SizedBox(
    width: width(220),
    height: height(50),
    // ignore: prefer_interpolation_to_compose_strings
    child: Image.network("http://solareasegp.runasp.net/" + batteryModel.Batteryimage),
  );
}
