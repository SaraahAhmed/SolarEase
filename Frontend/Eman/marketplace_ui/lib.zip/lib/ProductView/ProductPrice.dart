import 'package:flutter/material.dart';
import 'package:marketplace_ui/ProductView/Search.dart';
import 'package:marketplace_ui/ProductView/dropdownList.dart';
import 'package:marketplace_ui/main.dart';

class ProductPrices extends StatelessWidget {
  //const ProductPrices({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: 
      [
        DropDownList(),
        //SizedBox(height: 8,),
       
        
      ],
    );
  }
}