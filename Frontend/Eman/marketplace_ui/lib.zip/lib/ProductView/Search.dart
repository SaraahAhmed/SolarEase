import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:marketplace_ui/main.dart';

class SearchWidgwt extends StatelessWidget {
  //const SearchWidgwt({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
                 width:  width(590),height: height(16),
                  child: TextField
                  (
                    decoration: InputDecoration(
                      hintText: 'Search...',
                      filled: true,
                      fillColor: Color(0xffD9EDCA), 
                      suffixIcon: Container
                      (
                        width: 5,
                        height: 5,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xffED9555),
                        ),child: Icon(Icons.search,size: width(40),color: Colors.white,),
                      ),border: OutlineInputBorder
                      (
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide:BorderSide.none, 
                      ),
                    contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: width(10)),),
                    style: TextStyle(fontSize: 14 * t,),
                    textAlign: TextAlign.center, 
                    onChanged: (value){print('Search query: $value');},
          ),
        );
  }
}
  // Padding(
        //   padding: const EdgeInsets.symmetric(horizontal: 35,),
        //   child: SizedBox(
        //     width: width(590),height: height(16),
        //     child: TextField(
        //         onSubmitted: (value){print(value);},//0xffE2F1D7
        //         decoration: InputDecoration(
        //           fillColor: Color(0xffE2F1D7), // Set the background color here
        //           filled: true,
                       
        //           contentPadding: EdgeInsets.symmetric(vertical: 8,horizontal: 24),
        //           //hintText: "Enter product to search for . . .",
        //           hintStyle: TextStyle(color: Colors.grey),
        //           suffixIcon: Icon(Icons.search,color: Colors.orange,),
                  
        //           border: OutlineInputBorder
        //           (     
        //             borderSide: BorderSide(width:width(1), color: Colors.orange),
        //             borderRadius: BorderRadius.circular(24.0),
                    
        //           ),
            
                  
        //         ),
        //       ),
        //   ),
        // ),